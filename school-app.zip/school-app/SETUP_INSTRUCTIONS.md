# সেটআপ নোট — CodeIgniter 4-এর ডিফল্ট ফাইলে যা যোগ করতে হবে

## ১. app/Config/Filters.php
ডিফল্ট ফাইলে খুঁজে বের করো `public array $aliases` — সেখানে এই লাইনটা যোগ করো:

```php
'auth' => \App\Filters\AuthFilter::class,
```

## ২. app/Config/Routes.php
আমার দেওয়া Routes.php ফাইলটা দিয়ে ডিফল্ট ফাইলটা সম্পূর্ণ replace করে দিলেই হবে।

## ৩. .env ফাইল (রুট ফোল্ডারে, `env` ফাইলের কপি করে নাম দিতে হবে `.env`)
```
CI_ENVIRONMENT = development

app.baseURL = 'http://localhost:8080/'

database.default.hostname = localhost
database.default.database = school_db
database.default.username = root
database.default.password =
database.default.DBDriver = MySQLi
```
(cPanel-এ আপলোডের সময় baseURL এবং DB তথ্য বদলাতে হবে)

## ৪. প্রথম Admin ইউজার তৈরি (migration চালানোর পর)
Terminal-এ (local dev এ) অথবা একটা ছোট seeder script দিয়ে:
```php
password_hash('তোমার-পাসওয়ার্ড', PASSWORD_DEFAULT)
```
দিয়ে হ্যাশ বানিয়ে সরাসরি `users` টেবিলে একটা admin রো ঢুকিয়ে দিতে হবে (phpMyAdmin দিয়েও করা যায়)। এটা নিয়ে পরে বিস্তারিত গাইড দেবো।

## Migration চালানো (local এ, CLI দিয়ে)
```
php spark migrate
```

## ৫. স্কুলের নাম ও লোগো
- Admin প্যানেলে লগইন করে বাম পাশের মেনু থেকে **"স্কুলের তথ্য ও লোগো"**-তে গিয়ে যেকোনো সময় নাম ও লোগো বদলানো যাবে — এটা সাথে সাথে পুরো সাইটে (sidebar, লগইন পেজ, ব্রাউজার টাইটেল) দেখাবে।
- `public/uploads/logo/` ফোল্ডারে লোগো সেভ হয় — cPanel-এ আপলোডের সময় এই ফোল্ডারে **write permission (755 বা 775)** আছে কিনা চেক করে নিও, নাহলে লোগো আপলোড ফেইল করবে।
- `school_helper.php` ফাইলটা `app/Helpers/` এ আছে — এটা প্রতিটা ভিউতে `helper('school')` কল করে লোড করা হয়, আলাদা করে autoload কনফিগ করার দরকার নেই।

---
**যা এখনো বাকি:** Student CRUD, Attendance marking UI, Result entry UI, Fee module UI, Settings (Class/Subject/Year), User management, cPanel deployment গাইড।
