<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<?php if (! empty($enrollment)): ?>
    <!-- Single student view -->
    <div class="bg-white rounded-lg shadow p-6 mb-4">
        <h2 class="text-lg font-semibold mb-4">ফলাফল - ছাত্র/ছাত্রী #<?= esc($enrollment['student_id']) ?></h2>
        <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-gray-600 text-left">
                <tr>
                    <th class="px-4 py-2">পরীক্ষা</th>
                    <th class="px-4 py-2">মোট নাম্বার</th>
                    <th class="px-4 py-2">GPA</th>
                    <th class="px-4 py-2">অবস্থা</th>
                    <th class="px-4 py-2">কার্ড</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php foreach ($studentResults as $row): ?>
                    <?php $s = $row['summary']; ?>
                    <tr>
                        <td class="px-4 py-2"><?= esc($row['exam']['name']) ?></td>
                        <td class="px-4 py-2"><?= esc($s['total_marks_obtained'] ?? '-') ?></td>
                        <td class="px-4 py-2"><?= esc($s['gpa'] ?? '-') ?></td>
                        <td class="px-4 py-2">
                            <?php if (! $s): ?>
                                <span class="text-gray-400">এন্ট্রি হয়নি</span>
                            <?php elseif ($s['is_failed'] && ! $s['manual_pass_override']): ?>
                                <span class="text-red-600">Fail</span>
                            <?php elseif ($s['is_failed'] && $s['manual_pass_override']): ?>
                                <span class="text-yellow-600">Pass (override)</span>
                            <?php else: ?>
                                <span class="text-green-600">Pass</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2">
                            <a href="/results/card/<?= esc($enrollment['id']) ?>/<?= esc($row['exam']['id']) ?>" class="text-blue-600 hover:underline">দেখুন</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<div class="bg-white rounded-lg shadow p-6">
    <h3 class="font-semibold mb-3">ফলাফল এন্ট্রি করুন</h3>
    <a href="/results/entry" class="bg-slate-800 text-white px-4 py-2 rounded text-sm hover:bg-slate-700">
        নাম্বার এন্ট্রি পেজে যান
    </a>
</div>

<?= $this->endSection() ?>
