<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<form method="get" class="flex gap-2 mb-4">
    <select name="class_id" class="border rounded px-3 py-2 text-sm" onchange="this.form.submit()">
        <option value="">-- ক্লাস নির্বাচন করুন --</option>
        <?php foreach ($classes as $c): ?>
            <option value="<?= esc($c['id']) ?>" <?= (string) $selectedClassId === (string) $c['id'] ? 'selected' : '' ?>>
                <?= esc($c['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <input type="date" name="date" value="<?= esc($date) ?>" onchange="this.form.submit()" class="border rounded px-3 py-2 text-sm">
</form>

<?php if (! $currentYear): ?>
    <div class="bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-3 rounded">
        চলতি শিক্ষাবর্ষ নির্ধারিত নেই। <a href="/settings/classes" class="underline">এখানে সেট করুন</a>।
    </div>
<?php elseif (! $selectedClassId): ?>
    <div class="bg-white rounded-lg shadow p-6 text-gray-500 text-center">উপরে থেকে একটি ক্লাস নির্বাচন করুন।</div>
<?php else: ?>

<form action="/attendance/mark" method="post" class="bg-white rounded-lg shadow overflow-hidden">
    <?= csrf_field() ?>
    <input type="hidden" name="class_id" value="<?= esc($selectedClassId) ?>">
    <input type="hidden" name="date" value="<?= esc($date) ?>">

    <table class="min-w-full text-sm">
        <thead class="bg-gray-50 text-gray-600 text-left">
            <tr>
                <th class="px-4 py-3">রোল/নাম</th>
                <th class="px-4 py-3">কার্ড নম্বর</th>
                <th class="px-4 py-3 text-center">উপস্থিত</th>
                <th class="px-4 py-3 text-center">অনুপস্থিত</th>
                <th class="px-4 py-3">SMS</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php if (empty($roster)): ?>
                <tr><td colspan="5" class="px-4 py-6 text-center text-gray-400">এই ক্লাসে কোনো ছাত্র/ছাত্রী নেই।</td></tr>
            <?php endif; ?>
            <?php foreach ($roster as $r): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-2"><?= esc($r['name']) ?></td>
                    <td class="px-4 py-2"><?= esc($r['card_number'] ?? '-') ?></td>
                    <td class="px-4 py-2 text-center">
                        <input type="radio" name="status[<?= esc($r['student_id']) ?>]" value="present"
                               <?= ($r['status'] ?? '') === 'present' ? 'checked' : '' ?>>
                    </td>
                    <td class="px-4 py-2 text-center">
                        <input type="radio" name="status[<?= esc($r['student_id']) ?>]" value="absent"
                               <?= ($r['status'] ?? 'absent') === 'absent' ? 'checked' : '' ?>>
                    </td>
                    <td class="px-4 py-2 text-xs text-gray-500">
                        <?= ! empty($r['sms_sent']) ? '✅ পাঠানো হয়েছে' : '-' ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (! empty($roster)): ?>
    <div class="p-4 border-t">
        <button type="submit" class="bg-slate-800 text-white px-5 py-2 rounded hover:bg-slate-700">
            সংরক্ষণ করুন ও SMS পাঠান
        </button>
    </div>
    <?php endif; ?>
</form>

<?php endif; ?>

<?= $this->endSection() ?>
