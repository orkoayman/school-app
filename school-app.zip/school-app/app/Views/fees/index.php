<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="flex justify-between items-center mb-4">
    <form method="get" class="flex gap-2">
        <select name="class_id" class="border rounded px-3 py-2 text-sm" onchange="this.form.submit()">
            <option value="">সব ক্লাস</option>
            <?php foreach ($classes as $c): ?>
                <option value="<?= esc($c['id']) ?>" <?= (string) $selectedClassId === (string) $c['id'] ? 'selected' : '' ?>><?= esc($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </form>
    <a href="/fees/settings" class="text-sm text-blue-600 hover:underline">ফি রেট সেটিংস</a>
</div>

<?php if (! $currentYear): ?>
    <div class="bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-3 rounded">
        চলতি শিক্ষাবর্ষ নির্ধারিত নেই। <a href="/settings/classes" class="underline">এখানে সেট করুন</a>।
    </div>
<?php else: ?>

<div class="bg-white rounded-lg shadow overflow-x-auto">
    <table class="min-w-full text-sm">
        <thead class="bg-gray-50 text-gray-600 text-left">
            <tr>
                <th class="px-4 py-3">নাম</th>
                <th class="px-4 py-3">স্টুডেন্ট কোড</th>
                <th class="px-4 py-3">অভিভাবকের ফোন</th>
                <th class="px-4 py-3 text-right">মোট বকেয়া</th>
                <th class="px-4 py-3">কার্যক্রম</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php if (empty($rows)): ?>
                <tr><td colspan="5" class="px-4 py-6 text-center text-gray-400">কোনো ফি রেট এখনো সেট করা হয়নি, অথবা কোনো ছাত্র/ছাত্রী নেই।</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $r): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-2 font-medium"><?= esc($r['name']) ?></td>
                    <td class="px-4 py-2"><?= esc($r['student_code']) ?></td>
                    <td class="px-4 py-2"><?= esc($r['parent_phone']) ?></td>
                    <td class="px-4 py-2 text-right <?= $r['balance'] > 0 ? 'text-red-600 font-semibold' : 'text-green-600' ?>">
                        <?= number_format($r['balance'], 2) ?> ৳
                    </td>
                    <td class="px-4 py-2">
                        <a href="/fees/student/<?= esc($r['student_id']) ?>" class="text-blue-600 hover:underline">খতিয়ান দেখুন</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php endif; ?>

<?= $this->endSection() ?>
